import React, { useRef, useState, useMemo } from 'react';
import { Button, ScrollView, Image, Text, View, StyleSheet, Animated, PanResponder, Easing, Dimensions } from 'react-native';
import Constants from 'expo-constants';
import Dish from './Dish';

// You can import from local files
import AssetExample from './components/AssetExample';

export default function Order(orders, setOrders, setNote, orderno) {
    const value = useState(new Animated.Value(0))[0];
    let dishes = [];
    let completedorders = [];

    const animation = {
        toValue: -129,
        duration: 400,
        useNativeDriver: false,
        easing: Easing.cubic,
    };

    function moveBar() {
        Animated.timing(value, animation).start(({ finished }) => {
            console.log(completedorders);
            value.setValue(0);
            completedorders.push(orders[0]);
            setOrders(orders.filter((v, i) => i != 0));
        });
    }

    if (orders[0].Done.every(e => e)) {
        moveBar();
    }
    for (let i = 0; i < orders[orderno].Dish.length; i++) {
        dishes.push(Dish(orders, setOrders, setNote, orderno, i));
    }

    return (
        <Animated.View style={[Style.order, { top: value }]}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <Text>
                    {orders[orderno].odrName}
                </Text>
                <Text>
                    {orders[orderno].Time}
                </Text>
            </View>
            <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
                {dishes.map(elem => elem)}
            </View>
        </Animated.View>
    );
}

const Style = StyleSheet.create({
    order: {
        flexDirection: 'column',
        borderTopWidth: 1,
        borderTopColor: '#b3b0bf',
        width: '100%',
    }
});